package ProGAL.dataStructures;

import java.util.Comparator;

public class TournamentTree extends BinaryTree {

	public TournamentTree(Comparator compare) {
		
	}
}
