package ProGAL.geom2d;

/**
 * A parabola is the set of points that are equally distant from a focus point and the directrix, a fixed line
 */
public class Parabola {
	Point center;
	double r;
}
