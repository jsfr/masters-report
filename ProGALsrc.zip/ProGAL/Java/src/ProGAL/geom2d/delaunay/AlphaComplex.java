package ProGAL.geom2d.delaunay;

import ProGAL.geom2d.PointSet;
import ProGAL.geom2d.Triangulation.TriangulationAlgorithm;

public class AlphaComplex extends KineticDTBigEdges {
	
	public AlphaComplex(PointSet points) {
		super(points);
	}
}
