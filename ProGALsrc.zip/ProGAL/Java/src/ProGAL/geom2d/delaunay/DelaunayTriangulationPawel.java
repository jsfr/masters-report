package ProGAL.geom2d.delaunay;

import java.util.List;

import ProGAL.geom2d.Point;

public class DelaunayTriangulationPawel {

	public DelaunayTriangulationPawel(List<Point> P) {
		// randomly permute the points in P
		
		// pick lexicographically highest point p0 in P and let it be the first point in P
		 
	}
}
