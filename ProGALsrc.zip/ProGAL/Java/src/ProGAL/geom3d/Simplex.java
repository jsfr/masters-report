package ProGAL.geom3d;


/** TODO: Comment */
public interface Simplex extends Shape{
	
	/** TODO: Comment */
	public Point getPoint(int i);

	public int getDimension();
}
