package ProGAL.geom3d.complex.alphaComplex;

public interface SimplexAlphaProperties {
	public double getInAlphaComplex();
	public int getSimplexType();
	public boolean isAttached();
}
