package ProGAL.geom3d.complex.delaunayComplex;

import java.util.ArrayList;
import java.util.List;

import ProGAL.geom3d.Point;
import ProGAL.geom3d.PointWeighted;
import ProGAL.geom3d.complex.SimplicialComplex;

/** 
 * TODO: Fix
 * @author pawel
 *
 */
public class RegularComplex extends DelaunayComplex implements SimplicialComplex {

	public RegularComplex(List<Point> points) {
		super(points);
		// TODO Auto-generated constructor stub
	}
	
//	public RegularComplex(List<PointWeighted> points) {
//		super.compute();
//		// TODO Auto-generated constructor stub
//	}

}
