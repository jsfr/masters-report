package ProGAL.geom3d.tess;

public class TSphere {
	double w, x, y, z, sq;
}
