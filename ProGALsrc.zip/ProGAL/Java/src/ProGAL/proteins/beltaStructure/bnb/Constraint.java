package ProGAL.proteins.beltaStructure.bnb;

public interface Constraint {
	public boolean feasible(BnBNode n);

}
