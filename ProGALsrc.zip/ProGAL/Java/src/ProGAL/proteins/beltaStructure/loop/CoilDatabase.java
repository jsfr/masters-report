package ProGAL.proteins.beltaStructure.loop;

public class CoilDatabase {
	private static final String pdbSelect = "/Users/rfonseca/Documents/BioRepo/PDBSelect25/2009/pdb_chains/";
	
	public CoilDatabase(){
//		File dir = new File
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
