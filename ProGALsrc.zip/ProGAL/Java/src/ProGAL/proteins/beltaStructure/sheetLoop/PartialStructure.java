package ProGAL.proteins.beltaStructure.sheetLoop;

import ProGAL.proteins.structure.AminoAcidChain;

public interface PartialStructure {
	public void updateAtoms(AminoAcidChain chain);
}
