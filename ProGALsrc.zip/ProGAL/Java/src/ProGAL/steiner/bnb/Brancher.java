package ProGAL.steiner.bnb;

import java.util.Collection;

public interface Brancher {
	Collection<Node> branch(Node n); 
}
