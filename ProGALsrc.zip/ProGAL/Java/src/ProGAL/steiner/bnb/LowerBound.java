package ProGAL.steiner.bnb;

public interface LowerBound {
	double lowerBound(Node n);
}
